<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $image_id = $_POST['image_id'];
    $user_name = mysqli_real_escape_string($conn, $_POST['user_name']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    $query = "INSERT INTO gallerya_komentarfoto (image_id, user_name, comment) VALUES ('$image_id', '$user_name', '$comment')";
    mysqli_query($conn, $query);

    echo '<meta http-equiv="refresh" content="0;url=detail-image.php?id=' . $image_id . '">';
    exit();    
}
?>
