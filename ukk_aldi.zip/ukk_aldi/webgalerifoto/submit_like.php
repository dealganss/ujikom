<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $image_id = $_POST['image_id'];
    // Anda bisa menambahkan user_id jika pengguna login
    // $user_id = $_SESSION['user_id'];

    $query = "INSERT INTO gallery_likefoto (image_id, user_id) VALUES ('$image_id', '$user_id')";
    mysqli_query($conn, $query);

    header("Location: detail-image.php?id=$image_id");
}
?>
