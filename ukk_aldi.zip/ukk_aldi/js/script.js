// Kamu bisa menambahkan JavaScript untuk interaksi dinamis seperti AJAX.
console.log('JavaScript is connected!');